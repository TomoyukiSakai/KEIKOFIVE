const picChildren = document.querySelectorAll('.pic'); // .pic クラスを持つすべての要素を取得

picCb = function(entries, observer) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('inview');
        } else {
            entry.target.classList.remove('inview');
        }
    });
}

const io = new IntersectionObserver(picCb);

// すべての .pic 要素に対して observer を適用
picChildren.forEach(picChild => {
    io.observe(picChild);
});

class Menu{
    constructor(){
        this.DOM = {};
        this.DOM.btn = document.querySelector('.menu-btn');
        this.DOM.globalContainer = document.querySelector("#global-container");
        this.eventType = this._getEventType();
        this._addEvent();
    }

    _getEventType(){

        const isTouchCapable = "ontouchstart" in window;

        return isTouchCapable ? "touchstart" : "click";
    }

    _toggle(){
        this.DOM.globalContainer.classList.toggle('menu-open');
        
    }

    _addEvent(){
        this.DOM.btn.addEventListener(this.eventType, this._toggle.bind(this));
    }
    
}

new Menu();